﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace PharmacyDrugManagementSystem
{
    public partial class Cashier : Form
    {
        public Cashier()
        {
            InitializeComponent();
        }
        string conn = "Data Source=EXS\\SQLEXPRESS;Initial Catalog=PharmacyDrugInventoryMS;Integrated Security=True;Trust Server Certificate=True";
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Visible = true;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string orderId = textBox4.Text.Trim();

            if (string.IsNullOrEmpty(orderId))
            {
                MessageBox.Show("Please enter a valid OrderID.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(conn))
                {
                    string query = "SELECT OrderID, DrugName, Quantity, PricePerPiece, (Quantity * PricePerPiece) AS TotalPrice FROM PlacedOrders WHERE OrderID = @OrderID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@OrderID", orderId);

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();

                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count > 0)
                        {
                            dataGridView1.DataSource = dataTable;

                            // Calculate the total price
                            decimal totalSum = 0;
                            foreach (DataRow row in dataTable.Rows)
                            {
                                totalSum += Convert.ToDecimal(row["TotalPrice"]);
                            }

                            label3.Text = totalSum.ToString("F2") + " ETB";
                        }
                        else
                        {
                            MessageBox.Show("No records found for the given OrderID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            dataGridView1.DataSource = null;
                            label3.Text = "0.00 ETB";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void amountInput_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal totalAmount = 0;
                decimal enteredAmount = 0;

                // Parse the total amount from label3
                if (decimal.TryParse(label3.Text.Replace(" ETB", "").Trim(), out totalAmount) &&
                    decimal.TryParse(amountInput.Text.Trim(), out enteredAmount))
                {
                    // Calculate the remaining amount
                    decimal remainingAmount = enteredAmount - totalAmount;
                    if (remainingAmount > 0)
                    {
                        label4.Text = remainingAmount.ToString("F2") + " ETB";
                    }
                    else
                    {
                        label4.Text = "Insufficient fund";
                    }
                }
                else
                {
                    // Set default value if parsing fails
                    label4.Text = "0.00 ETB";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while calculating the remaining amount: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string orderId = textBox4.Text.Trim();

            if (string.IsNullOrEmpty(orderId))
            {
                MessageBox.Show("Please enter a valid OrderID.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                decimal remainingAmount = 0;
                if (!decimal.TryParse(label4.Text.Replace("$", ""), out remainingAmount) || remainingAmount < 0)
                {
                    MessageBox.Show("The remaining amount must be greater than or equal to 0 to update the status.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(conn))
                {
                    connection.Open();

                    // Check if the status is already paid
                    string checkQuery = "SELECT Status FROM PlacedOrders WHERE OrderID = @OrderID";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@OrderID", orderId);
                        object statusResult = checkCommand.ExecuteScalar();

                        if (statusResult != null && statusResult.ToString().Equals("Paid", StringComparison.OrdinalIgnoreCase))
                        {
                            MessageBox.Show("The order is already paid.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }

                    // Update the status to paid
                    string updateQuery = "UPDATE PlacedOrders SET Status = 'Paid' WHERE OrderID = @OrderID";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@OrderID", orderId);
                        int rowsAffected = updateCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("The Order has been Paid.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No rows were updated. Please check the OrderID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating the order status: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Check if a row is selected
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Get the selected row
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

            string OrderID = selectedRow.Cells["OrderID"].Value?.ToString();
            string query = "DELETE FROM PlacedOrders WHERE OrderID = @OrderID";

            using (SqlConnection sqlConnection = new SqlConnection(conn))
            using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
            {
                // Add parameter to prevent SQL injection
                sqlCommand.Parameters.AddWithValue("@OrderID", OrderID);

                // Open the connection and execute the query
                sqlConnection.Open();
                int rowsAffected = sqlCommand.ExecuteNonQuery();

                // Notify the user and refresh the DataGridView
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Order Canceled!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Optionally refresh the data
                }
                else
                {
                    MessageBox.Show("Failed to cancele the order. It may have been deleted already.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                // Clear all the specified controls
                label3.Text = "$0.00";
                label4.Text = "$0.00";
                amountInput.Text = string.Empty;
                textBox4.Text = string.Empty;
                dataGridView1.DataSource = null;
            }
        }
    }
}
