﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace PharmacyDrugManagementSystem
{
    public partial class adminDashboard : UserControl
    {
        public adminDashboard()
        {
            InitializeComponent();
            UpdateLabels();
        }

        string conn = "Data Source=EXS\\SQLEXPRESS;Initial Catalog=PharmacyDrugInventoryMS;Integrated Security=True;Trust Server Certificate=True";

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void UpdateLabels()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(conn))
                {
                    connection.Open();

                    // Query to calculate the total price
                    string totalPriceQuery = "SELECT SUM(Quantity * PricePerPiece) AS TotalPrice FROM SoldDrugs";
                    string totalQuantityQuery = "SELECT SUM(Quantity) AS TotalQuantity FROM SoldDrugs";

                    using (SqlCommand priceCommand = new SqlCommand(totalPriceQuery, connection))
                    using (SqlCommand quantityCommand = new SqlCommand(totalQuantityQuery, connection))
                    {
                        // Fetch total price
                        object totalPriceResult = priceCommand.ExecuteScalar();
                        label3.Text = totalPriceResult != DBNull.Value
                            ? $"{Convert.ToDecimal(totalPriceResult)} ETB"
                            : "0.00 ETB";

                        // Fetch total quantity
                        object totalQuantityResult = quantityCommand.ExecuteScalar();
                        label6.Text = totalQuantityResult != DBNull.Value
                            ? $"{Convert.ToInt32(totalQuantityResult)}"
                            : "0";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle errors gracefully
                label3.Text = "Error fetching total sales.";
                label6.Text = "Error fetching total quantity.";
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(conn))
                {
                    connection.Open();

                    // Query to fetch relevant data from Inventory
                    string query = @"
                SELECT 
                    DrugName, 
                    Quantity, 
                    ExpirationDate,
                    CASE 
                        WHEN ExpirationDate < GETDATE() THEN 'Expired'
                        WHEN DATEDIFF(DAY, GETDATE(), ExpirationDate) <= 10 THEN 
                            CAST(DATEDIFF(DAY, GETDATE(), ExpirationDate) AS NVARCHAR) + ' days to expire'
                        WHEN Quantity = 0 THEN 'Out of stock'
                        WHEN Quantity < 10 THEN 'Scarce'
                        ELSE 'In stock'
                    END AS Status
                FROM Inventory
                WHERE 
                    ExpirationDate < GETDATE()
                    OR DATEDIFF(DAY, GETDATE(), ExpirationDate) <= 10
                    OR Quantity = 0
                    OR Quantity < 10";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        // Fetch data and populate the DataGridView
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        // Configure and populate dataGridView1
                        dataGridView1.DataSource = table;

                        // Auto-resize columns for better visibility
                        dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                        // Set column headers explicitly (optional for clarity)
                        dataGridView1.Columns["DrugName"].HeaderText = "Drug Name";
                        dataGridView1.Columns["Quantity"].HeaderText = "Quantity";
                        dataGridView1.Columns["ExpirationDate"].HeaderText = "Expiration Date";
                        dataGridView1.Columns["Status"].HeaderText = "Status";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching inventory data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void panel1_Leave(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
        }
    }
}
