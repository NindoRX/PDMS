﻿namespace PharmacyDrugManagementSystem
{
    partial class Pharmacist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pharmacist));
            panel2 = new Panel();
            pendingOrders1 = new PendingOrders();
            placeOrder1 = new PlaceOrder();
            panel1 = new Panel();
            button4 = new Button();
            button3 = new Button();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(1, 39, 60);
            panel2.Controls.Add(pendingOrders1);
            panel2.Controls.Add(placeOrder1);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(266, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(844, 729);
            panel2.TabIndex = 3;
            panel2.Paint += panel2_Paint;
            // 
            // pendingOrders1
            // 
            pendingOrders1.Dock = DockStyle.Fill;
            pendingOrders1.Location = new Point(0, 0);
            pendingOrders1.Name = "pendingOrders1";
            pendingOrders1.Size = new Size(844, 729);
            pendingOrders1.TabIndex = 1;
            // 
            // placeOrder1
            // 
            placeOrder1.Dock = DockStyle.Fill;
            placeOrder1.Location = new Point(0, 0);
            placeOrder1.Name = "placeOrder1";
            placeOrder1.Size = new Size(844, 729);
            placeOrder1.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(53, 60, 66);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(266, 729);
            panel1.TabIndex = 2;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(96, 113, 120);
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.Transparent;
            button4.Location = new Point(4, 394);
            button4.Name = "button4";
            button4.Size = new Size(256, 45);
            button4.TabIndex = 5;
            button4.Text = "Pending Orders";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(96, 113, 120);
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.Transparent;
            button3.Location = new Point(4, 310);
            button3.Name = "button3";
            button3.Size = new Size(256, 45);
            button3.TabIndex = 4;
            button3.Text = "Place An Order";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(96, 113, 120);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Transparent;
            button1.Location = new Point(4, 672);
            button1.Name = "button1";
            button1.Size = new Size(256, 45);
            button1.TabIndex = 2;
            button1.Text = "SIGN OUT";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(4, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(256, 256);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Pharmacist
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1110, 729);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Pharmacist";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pharmacist";
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private Panel panel1;
        private Button button1;
        private PictureBox pictureBox1;
        private Button button3;
        private Button button4;
        private PlaceOrder placeOrder1;
        private PendingOrders pendingOrders1;
    }
}