﻿namespace PharmacyDrugManagementSystem
{
    partial class adminDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminDashboard));
            panel1 = new Panel();
            panel6 = new Panel();
            label4 = new Label();
            pictureBox4 = new PictureBox();
            panel5 = new Panel();
            label6 = new Label();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            panel4 = new Panel();
            label3 = new Label();
            label5 = new Label();
            pictureBox3 = new PictureBox();
            dataGridView1 = new DataGridView();
            panel1.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(1, 39, 60);
            panel1.Controls.Add(panel6);
            panel1.Controls.Add(panel5);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(dataGridView1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(843, 729);
            panel1.TabIndex = 0;
            panel1.Leave += panel1_Leave;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(115, 130, 173);
            panel6.Controls.Add(label4);
            panel6.Controls.Add(pictureBox4);
            panel6.Location = new Point(574, 54);
            panel6.Name = "panel6";
            panel6.Size = new Size(217, 191);
            panel6.TabIndex = 9;
            panel6.Click += panel6_Click;
            panel6.Paint += panel6_Paint;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label4.ForeColor = Color.White;
            label4.Location = new Point(17, 141);
            label4.Name = "label4";
            label4.Size = new Size(153, 32);
            label4.TabIndex = 31;
            label4.Text = "Drug Status";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.project;
            pictureBox4.Location = new Point(27, 29);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(78, 76);
            pictureBox4.TabIndex = 6;
            pictureBox4.TabStop = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(115, 130, 173);
            panel5.Controls.Add(label6);
            panel5.Controls.Add(label2);
            panel5.Controls.Add(pictureBox2);
            panel5.Location = new Point(313, 54);
            panel5.Name = "panel5";
            panel5.Size = new Size(217, 191);
            panel5.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 12F, FontStyle.Bold | FontStyle.Italic);
            label6.ForeColor = Color.White;
            label6.Location = new Point(142, 11);
            label6.Name = "label6";
            label6.Size = new Size(20, 23);
            label6.TabIndex = 32;
            label6.Text = "0";
            label6.Click += label6_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label2.ForeColor = Color.White;
            label2.Location = new Point(13, 141);
            label2.Name = "label2";
            label2.Size = new Size(201, 32);
            label2.TabIndex = 31;
            label2.Text = "Total Items Sold";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(28, 29);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(78, 76);
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(115, 130, 173);
            panel4.Controls.Add(label3);
            panel4.Controls.Add(label5);
            panel4.Controls.Add(pictureBox3);
            panel4.Location = new Point(43, 56);
            panel4.Name = "panel4";
            panel4.Size = new Size(217, 191);
            panel4.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Bold | FontStyle.Italic);
            label3.ForeColor = Color.White;
            label3.Location = new Point(97, 9);
            label3.Name = "label3";
            label3.Size = new Size(55, 23);
            label3.TabIndex = 32;
            label3.Text = "$0.00";
            label3.Click += label3_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label5.ForeColor = Color.White;
            label5.Location = new Point(18, 139);
            label5.Name = "label5";
            label5.Size = new Size(134, 32);
            label5.TabIndex = 31;
            label5.Text = "Total Sells";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(18, 27);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(78, 76);
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(43, 299);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(748, 397);
            dataGridView1.TabIndex = 5;
            // 
            // adminDashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "adminDashboard";
            Size = new Size(843, 729);
            panel1.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private DataGridView dataGridView1;
        private Panel panel6;
        private Label label4;
        private PictureBox pictureBox4;
        private Panel panel5;
        private Label label6;
        private Label label2;
        private PictureBox pictureBox2;
        private Panel panel4;
        private Label label3;
        private Label label5;
        private PictureBox pictureBox3;
    }
}
