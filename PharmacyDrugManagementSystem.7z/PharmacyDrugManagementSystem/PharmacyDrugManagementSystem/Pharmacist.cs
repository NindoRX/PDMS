﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PharmacyDrugManagementSystem
{
    public partial class Pharmacist : Form
    {
        public Pharmacist()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Visible = true;
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            placeOrder1.Visible = true;
            pendingOrders1.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            placeOrder1.Visible = false;
            pendingOrders1.Visible = true;
        }

        private void placeOrder1_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            placeOrder1.BringToFront();
        }

        private void placeOrder1_Load_2(object sender, EventArgs e)
        {

        }
    }
}
