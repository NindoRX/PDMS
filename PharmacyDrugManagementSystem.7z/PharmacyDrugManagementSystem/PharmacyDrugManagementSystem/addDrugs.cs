﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PharmacyDrugManagementSystem
{
    public partial class addDrugs : UserControl
    {
        public addDrugs()
        {
            InitializeComponent();
        }
        string conn = "Data Source=EXS\\SQLEXPRESS;Initial Catalog=PharmacyDrugInventoryMS;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";

        private void clearTextFields()
        {
            txtDrug.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
            dateTimePicker1.Value = DateTime.Now;
            pictureBox1.Image = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if a row is selected
                if (dataGridView2.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a row to update.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Get the selected row
                DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];

                // Get the original DrugName of the selected row (assuming DrugName is the unique identifier)
                string originalDrugName = selectedRow.Cells["DrugName"].Value?.ToString();

                if (string.IsNullOrEmpty(originalDrugName))
                {
                    MessageBox.Show("Unable to identify the selected record. Update aborted.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Get updated values from input fields
                string updatedDrugName = txtDrug.Text.Trim();
                if (string.IsNullOrEmpty(updatedDrugName))
                {
                    MessageBox.Show("Please enter a valid drug name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int updatedQuantity = int.TryParse(textBox2.Text.Trim(), out int quantity) && quantity > 0 ? quantity : throw new ArgumentException("Invalid quantity.");
                decimal updatedPrice = decimal.TryParse(textBox3.Text.Trim(), out decimal price) && price > 0 ? price : throw new ArgumentException("Invalid price.");
                DateTime updatedExpirationDate = dateTimePicker1.Value;

                // Convert the image from pictureBox1 to a byte array
                byte[] updatedPhoto = null;
                if (pictureBox1.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        pictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        updatedPhoto = ms.ToArray();
                    }
                }

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlCommand sqlCommand = new SqlCommand("UpdateDrugInInventory", sqlConnection))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;

                    // Add parameters to the stored procedure
                    sqlCommand.Parameters.AddWithValue("@OriginalDrugName", originalDrugName);
                    sqlCommand.Parameters.AddWithValue("@UpdatedDrugName", updatedDrugName);
                    sqlCommand.Parameters.AddWithValue("@UpdatedQuantity", updatedQuantity);
                    sqlCommand.Parameters.AddWithValue("@UpdatedPrice", updatedPrice);
                    sqlCommand.Parameters.AddWithValue("@UpdatedExpirationDate", updatedExpirationDate);
                    sqlCommand.Parameters.AddWithValue("@UpdatedPhoto", (object)updatedPhoto ?? DBNull.Value);

                    // Open the connection and execute the stored procedure
                    sqlConnection.Open();
                    int rowsAffected = sqlCommand.ExecuteNonQuery();

                    // Notify the user and refresh the DataGridView
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        button6_Click(null, null); // Refresh dataGridView2 by reloading data
                    }
                    else
                    {
                        MessageBox.Show("Failed to update the record. It may have been deleted or modified by another user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    clearTextFields();
                }
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Retrieve values from input fields
                string drugName = txtDrug.Text.Trim();
                int quantity;
                decimal price;
                DateTime expirationDate = dateTimePicker1.Value;

                // Validate inputs
                if (string.IsNullOrEmpty(drugName))
                {
                    MessageBox.Show("Please enter a valid drug name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(textBox2.Text.Trim(), out quantity) || quantity <= 0)
                {
                    MessageBox.Show("Please enter a valid quantity.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!decimal.TryParse(textBox3.Text.Trim(), out price) || price <= 0)
                {
                    MessageBox.Show("Please enter a valid price.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Convert pictureBox1 image to byte array
                byte[] photo = null;
                if (pictureBox1.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
                        photo = ms.ToArray();
                    }
                }
                else
                {
                    MessageBox.Show("Please select an image for the drug.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlCommand sqlCommand = new SqlCommand("AddDrugToInventory", sqlConnection))
                {
                    // Specify that the command is a stored procedure
                    sqlCommand.CommandType = CommandType.StoredProcedure;

                    // Add parameters to the command
                    sqlCommand.Parameters.AddWithValue("@DrugName", drugName);
                    sqlCommand.Parameters.AddWithValue("@Quantity", quantity);
                    sqlCommand.Parameters.AddWithValue("@Price", price);
                    sqlCommand.Parameters.AddWithValue("@ExpirationDate", expirationDate);
                    sqlCommand.Parameters.AddWithValue("@Photo", photo);

                    // Open the connection and execute the stored procedure
                    sqlConnection.Open();
                    int rowsAffected = sqlCommand.ExecuteNonQuery();

                    // Notify the user of the result
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Drug information added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Failed to add drug information.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    clearTextFields();
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
                openFileDialog.Title = "Select an Image";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Load the selected image into the PictureBox
                        pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage; // Optional: Adjusts the size mode
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading image: " + ex.Message);
                    }
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                // Name of the stored procedure
                string storedProcedure = "GetAllInventory";

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlCommand sqlCommand = new SqlCommand(storedProcedure, sqlConnection))
                {
                    // Specify that the command is a stored procedure
                    sqlCommand.CommandType = CommandType.StoredProcedure;

                    // Open the connection
                    sqlConnection.Open();

                    // Execute the stored procedure and load the data into a DataTable
                    using (SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        // Add a new column for images in the DataGridView
                        if (!dataTable.Columns.Contains("ImageColumn"))
                        {
                            dataTable.Columns.Add("ImageColumn", typeof(Image));
                        }

                        // Convert the Photo column (byte array) to an Image for display
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (row["Photo"] != DBNull.Value)
                            {
                                byte[] photoBytes = (byte[])row["Photo"];
                                using (MemoryStream ms = new MemoryStream(photoBytes))
                                {
                                    row["ImageColumn"] = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                row["ImageColumn"] = null; // No image available
                            }
                        }

                        // Remove the raw Photo column for cleaner display
                        dataTable.Columns.Remove("Photo");

                        // Bind the updated DataTable to the DataGridView
                        dataGridView2.DataSource = dataTable;

                        // Auto-size columns for better display
                        dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                        // Configure the image column for better presentation
                        if (dataGridView2.Columns.Contains("ImageColumn"))
                        {
                            DataGridViewImageColumn imageColumn = (DataGridViewImageColumn)dataGridView2.Columns["ImageColumn"];
                            imageColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // Ensure the selected row index is valid
                if (e.RowIndex >= 0)
                {
                    // Get the selected row
                    DataGridViewRow selectedRow = dataGridView2.Rows[e.RowIndex];

                    // Map the data to input fields
                    txtDrug.Text = selectedRow.Cells["DrugName"].Value?.ToString();
                    textBox2.Text = selectedRow.Cells["Quantity"].Value?.ToString();
                    textBox3.Text = selectedRow.Cells["Price"].Value?.ToString();
                    dateTimePicker1.Value = Convert.ToDateTime(selectedRow.Cells["ExpirationDate"].Value);

                    // Load the image into pictureBox1
                    if (selectedRow.Cells["ImageColumn"].Value != null)
                    {
                        pictureBox1.Image = (Image)selectedRow.Cells["ImageColumn"].Value;
                    }
                    else
                    {
                        pictureBox1.Image = null; // Clear the pictureBox1 if no image is available
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while mapping the data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if a row is selected
                if (dataGridView2.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a row to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Get the selected row
                DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];

                // Confirm deletion
                DialogResult dialogResult = MessageBox.Show(
                    "Are you sure you want to delete the selected record?",
                    "Confirm Deletion",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (dialogResult == DialogResult.Yes)
                {
                    // Get the primary key or unique identifier of the row to delete
                    string drugName = selectedRow.Cells["DrugName"].Value?.ToString();

                    if (string.IsNullOrEmpty(drugName))
                    {
                        MessageBox.Show("Unable to identify the selected record. Deletion aborted.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    using (SqlConnection sqlConnection = new SqlConnection(conn))
                    using (SqlCommand sqlCommand = new SqlCommand("DeleteDrugFromInventory", sqlConnection))
                    {
                        // Specify that the command is a stored procedure
                        sqlCommand.CommandType = CommandType.StoredProcedure;

                        // Add parameter to the stored procedure
                        sqlCommand.Parameters.AddWithValue("@DrugName", drugName);

                        // Open the connection and execute the stored procedure
                        sqlConnection.Open();
                        int rowsAffected = sqlCommand.ExecuteNonQuery();

                        // Notify the user and refresh the DataGridView
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            // Optionally refresh the data
                            button6_Click(null, null); // Refresh dataGridView2 by reloading data
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete the record. It may have been deleted already.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        clearTextFields();
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the search text from textBox4
                string searchText = textBox4.Text.Trim();

                if (string.IsNullOrEmpty(searchText))
                {
                    MessageBox.Show("Please enter a Drug Name to search.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlCommand sqlCommand = new SqlCommand("SearchInventory", sqlConnection))
                {
                    // Specify that the command is a stored procedure
                    sqlCommand.CommandType = CommandType.StoredProcedure;

                    // Add parameter for the search query
                    sqlCommand.Parameters.AddWithValue("@SearchText", searchText);

                    // Open the connection
                    sqlConnection.Open();

                    // Execute the query and load the data into a DataTable
                    using (SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        // Add a new column for images in the DataGridView
                        if (!dataTable.Columns.Contains("ImageColumn"))
                        {
                            dataTable.Columns.Add("ImageColumn", typeof(Image));
                        }

                        // Convert the Photo column (byte array) to an Image for display
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (row["Photo"] != DBNull.Value)
                            {
                                byte[] photoBytes = (byte[])row["Photo"];
                                using (MemoryStream ms = new MemoryStream(photoBytes))
                                {
                                    row["ImageColumn"] = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                row["ImageColumn"] = null; // No image available
                            }
                        }

                        // Remove the raw Photo column for cleaner display
                        dataTable.Columns.Remove("Photo");

                        // Bind the updated DataTable to the DataGridView
                        dataGridView2.DataSource = dataTable;

                        // Auto-size columns for better display
                        dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                        // Configure the image column for better presentation
                        if (dataGridView2.Columns.Contains("ImageColumn"))
                        {
                            DataGridViewImageColumn imageColumn = (DataGridViewImageColumn)dataGridView2.Columns["ImageColumn"];
                            imageColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
                        }

                        // Notify the user if no records are found
                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("No records found matching the search criteria.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void panel1_Leave(object sender, EventArgs e)
        {
            dataGridView2.DataSource = null;
            dataGridView2.Rows.Clear();
        }
    }
}
