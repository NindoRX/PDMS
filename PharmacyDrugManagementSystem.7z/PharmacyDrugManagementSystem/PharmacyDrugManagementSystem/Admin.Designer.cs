﻿namespace PharmacyDrugManagementSystem
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            addUsers1 = new addUsers();
            addDrugs1 = new addDrugs();
            adminDashboard1 = new adminDashboard();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(53, 60, 66);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(266, 743);
            panel1.TabIndex = 0;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(96, 113, 120);
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.Transparent;
            button4.Location = new Point(9, 671);
            button4.Name = "button4";
            button4.Size = new Size(248, 45);
            button4.TabIndex = 4;
            button4.Text = "SIGN OUT";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(96, 113, 120);
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.Transparent;
            button3.Location = new Point(9, 473);
            button3.Name = "button3";
            button3.Size = new Size(248, 45);
            button3.TabIndex = 3;
            button3.Text = "Add Users";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(96, 113, 120);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Transparent;
            button2.Location = new Point(9, 384);
            button2.Name = "button2";
            button2.Size = new Size(248, 45);
            button2.TabIndex = 2;
            button2.Text = "Add Drugs";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(96, 113, 120);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Transparent;
            button1.Location = new Point(7, 299);
            button1.Name = "button1";
            button1.Size = new Size(248, 45);
            button1.TabIndex = 1;
            button1.Text = "Dashboard";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.admin;
            pictureBox1.Location = new Point(7, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(256, 256);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(1, 39, 60);
            panel2.Controls.Add(adminDashboard1);
            panel2.Controls.Add(addUsers1);
            panel2.Controls.Add(addDrugs1);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(266, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(867, 743);
            panel2.TabIndex = 1;
            panel2.Paint += panel2_Paint;
            // 
            // addUsers1
            // 
            addUsers1.Dock = DockStyle.Fill;
            addUsers1.Location = new Point(0, 0);
            addUsers1.Name = "addUsers1";
            addUsers1.Size = new Size(867, 743);
            addUsers1.TabIndex = 1;
            addUsers1.Load += addUsers1_Load;
            // 
            // addDrugs1
            // 
            addDrugs1.Dock = DockStyle.Fill;
            addDrugs1.Location = new Point(0, 0);
            addDrugs1.Name = "addDrugs1";
            addDrugs1.Size = new Size(867, 743);
            addDrugs1.TabIndex = 0;
            // 
            // adminDashboard1
            // 
            adminDashboard1.Dock = DockStyle.Fill;
            adminDashboard1.Location = new Point(0, 0);
            adminDashboard1.Name = "adminDashboard1";
            adminDashboard1.Size = new Size(867, 743);
            adminDashboard1.TabIndex = 2;
            adminDashboard1.Load += adminDashboard1_Load;
            // 
            // Admin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1133, 743);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Admin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private Panel panel2;
        private Button button1;
        private Button button4;
        private Button button3;
        private Button button2;
        private addUsers addUsers1;
        private addDrugs addDrugs1;
        private adminDashboard adminDashboard1;
    }
}