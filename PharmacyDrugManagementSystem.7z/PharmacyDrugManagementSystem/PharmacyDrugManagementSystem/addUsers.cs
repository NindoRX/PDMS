﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PharmacyDrugManagementSystem
{
    public partial class addUsers : UserControl
    {
        public addUsers()
        {
            InitializeComponent();
        }

        string conn = "Data Source=EXS\\SQLEXPRESS;Initial Catalog=PharmacyDrugInventoryMS;Integrated Security=True;Trust Server Certificate=True";

        private void label3_Click(object sender, EventArgs e)
        {

        }
        // Hashing function
        string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashedBytes)
                {
                    sb.Append(b.ToString("x2")); // Convert byte to hex
                }
                return sb.ToString();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            // Retrieve user input
            string userName = txtUserName.Text.Trim();
            string role = cmbRole.SelectedItem?.ToString();
            string password = txtPassword.Text.Trim();

            // Validate inputs
            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(role) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("All fields are required!", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Hash the password using SHA-256
            string hashedPassword = HashPassword(password);

            // Stored procedure names
            string checkProcedure = "CheckUserExists";
            string insertProcedure = "InsertUser";

            try
            {
                using (SqlConnection connection = new SqlConnection(conn))
                {
                    connection.Open();

                    // Check if the user already exists
                    using (SqlCommand checkCommand = new SqlCommand(checkProcedure, connection))
                    {
                        checkCommand.CommandType = CommandType.StoredProcedure;

                        // Add parameters
                        checkCommand.Parameters.AddWithValue("@UserName", userName);
                        checkCommand.Parameters.AddWithValue("@Password", hashedPassword);

                        int userExists = (int)checkCommand.ExecuteScalar();

                        if (userExists > 0)
                        {
                            MessageBox.Show("User with the same username and password already exists!", "Duplicate Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // Insert the new user
                    using (SqlCommand insertCommand = new SqlCommand(insertProcedure, connection))
                    {
                        insertCommand.CommandType = CommandType.StoredProcedure;

                        // Add parameters
                        insertCommand.Parameters.AddWithValue("@UserName", userName);
                        insertCommand.Parameters.AddWithValue("@Role", role);
                        insertCommand.Parameters.AddWithValue("@Password", hashedPassword);

                        int rowsAffected = insertCommand.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("User added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearDataGridView2();
                        }
                        else
                        {
                            MessageBox.Show("Failed to add user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        clearTextFields();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearDataGridView2()
        {
            dataGridView2.DataSource = null;
            dataGridView2.Rows.Clear();

            string query = "SELECT UserName, Role FROM Users";
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView2.DataSource = dataTable;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string conn = "Data Source=EXS\\SQLEXPRESS;Initial Catalog=PharmacyDrugInventoryMS;Integrated Security=True;Trust Server Certificate=True";

                string query = "SELECT UserName, Role, Password FROM Users";

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlConnection.Open();

                    using (SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        dataGridView2.DataSource = dataTable;

                        dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a user to delete.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirmation = MessageBox.Show("Are you sure you want to delete the selected user?", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmation == DialogResult.Yes)
            {
                string conn = "Data Source=EXS\\SQLEXPRESS;Initial Catalog=PharmacyDrugInventoryMS;Integrated Security=True;Trust Server Certificate=True";
                string deleteQuery = "DELETE FROM Users WHERE UserName = @UserName";

                try
                {
                    string userName = dataGridView2.SelectedRows[0].Cells["UserName"].Value.ToString();

                    using (SqlConnection connection = new SqlConnection(conn))
                    {
                        connection.Open();

                        using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                        {
                            deleteCommand.Parameters.AddWithValue("@UserName", userName);

                            int rowsAffected = deleteCommand.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("User deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                button1_Click(sender, e);
                            }
                            else
                            {
                                MessageBox.Show("Failed to delete user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            clearTextFields();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a user to update.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirmation = MessageBox.Show("Are you sure you want to update the selected user?", "Update Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmation == DialogResult.Yes)
            {
                string updateQuery = "UPDATE Users SET Role = @Role, Password = @Password WHERE UserName = @UserName";

                try
                {
                    string userName = txtUserName.Text.Trim();
                    string role = cmbRole.SelectedItem?.ToString();
                    string password = txtPassword.Text.Trim();

                    // Validate inputs
                    if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(role) || string.IsNullOrEmpty(password))
                    {
                        MessageBox.Show("All fields are required!", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Hash the password using SHA-256
                    string hashedPassword = HashPassword(password);

                    using (SqlConnection connection = new SqlConnection(conn))
                    {
                        connection.Open();

                        using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                        {
                            updateCommand.Parameters.AddWithValue("@UserName", userName);
                            updateCommand.Parameters.AddWithValue("@Role", role);
                            updateCommand.Parameters.AddWithValue("@Password", hashedPassword);

                            int rowsAffected = updateCommand.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("User updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Refresh the DataGridView
                                button1_Click(sender, e);
                            }
                            else
                            {
                                MessageBox.Show("Failed to update user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            clearTextFields();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void clearTextFields()
        {
            txtUserName.Text = null;
            txtPassword.Text = null;
            cmbRole.Text = null;
        }

        private void dataGridView2_SelectionChanged_1(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                // Load selected row values into input fields
                txtUserName.Text = dataGridView2.SelectedRows[0].Cells["UserName"].Value.ToString();
                cmbRole.SelectedItem = dataGridView2.SelectedRows[0].Cells["Role"].Value.ToString();

                // Fetch the hashed password from the database
                string selectedUserName = txtUserName.Text.Trim();
                try
                {
                    using (SqlConnection connection = new SqlConnection(conn))
                    {
                        connection.Open();

                        string query = "SELECT Password FROM Users WHERE UserName = @UserName";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@UserName", selectedUserName);

                            object result = command.ExecuteScalar();
                            if (result != null)
                            {
                                txtPassword.Text = result.ToString();
                            }
                            else
                            {
                                txtPassword.Text = string.Empty;
                                MessageBox.Show("No password found for the selected user.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error fetching password: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the UserName from textBox1 and trim any extra spaces
                string userName = textBox1.Text.Trim();

                // Validate input
                if (string.IsNullOrEmpty(userName))
                {
                    MessageBox.Show("Please enter a UserName to search.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Name of the stored procedure
                string storedProcedure = "SearchUserByUserName";

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlCommand sqlCommand = new SqlCommand(storedProcedure, sqlConnection))
                {
                    // Specify that the command is a stored procedure
                    sqlCommand.CommandType = CommandType.StoredProcedure;

                    // Add parameter to prevent SQL injection
                    sqlCommand.Parameters.AddWithValue("@UserName", userName);

                    // Open the connection
                    sqlConnection.Open();

                    using (SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        // Bind the result to the DataGridView
                        dataGridView2.DataSource = dataTable;

                        // Auto-size columns for better display
                        dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                        // Notify the user if no records are found
                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("No user found matching the provided UserName.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Leave(object sender, EventArgs e)
        {
            dataGridView2.DataSource = null;
            dataGridView2.Rows.Clear();
        }
    }
}
