﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PharmacyDrugManagementSystem
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Visible = true;
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            addDrugs1.Visible = true;
            addUsers1.Visible = false;
            adminDashboard1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addDrugs1.Visible = false;
            adminDashboard1.Visible = false;
            addUsers1.Visible = true;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            adminDashboard1.BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addDrugs1.Visible = false;
            adminDashboard1.Visible = true;
            addUsers1.Visible = false;
        }

        private void addUsers1_Load(object sender, EventArgs e)
        {

        }

        private void adminDashboard1_Load(object sender, EventArgs e)
        {

        }
    }
}
