﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PharmacyDrugManagementSystem
{
    public partial class PlaceOrder : UserControl
    {
        public PlaceOrder()
        {
            InitializeComponent();
        }
        string conn = "Data Source=EXS\\SQLEXPRESS;Initial Catalog=PharmacyDrugInventoryMS;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void updateLables()
        {
            label7.Text = "- - - - -";
            label8.Text = "- - - - -";
            textBox2.Text = null;
            textBox4.Text = null;
            dataGridView2.DataSource = null;
            dataGridView2.Rows.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the search text from textBox4
                string searchText = textBox4.Text.Trim();

                if (string.IsNullOrEmpty(searchText))
                {
                    MessageBox.Show("Please enter a Drug Name to search.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // SQL query to filter Inventory by DrugName
                string query = "SELECT DrugName, Quantity, Price, ExpirationDate, Photo FROM Inventory WHERE DrugName LIKE @SearchText";

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    // Add parameter for the search query
                    sqlCommand.Parameters.AddWithValue("@SearchText", $"%{searchText}%");

                    // Open the connection
                    sqlConnection.Open();

                    // Execute the query and load the data into a DataTable
                    using (SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        // Add a new column for images in the DataGridView
                        if (!dataTable.Columns.Contains("ImageColumn"))
                        {
                            dataTable.Columns.Add("ImageColumn", typeof(Image));
                        }

                        // Convert the Photo column (byte array) to an Image for display
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (row["Photo"] != DBNull.Value)
                            {
                                byte[] photoBytes = (byte[])row["Photo"];
                                using (MemoryStream ms = new MemoryStream(photoBytes))
                                {
                                    row["ImageColumn"] = Image.FromStream(ms);
                                }
                            }
                            else
                            {
                                row["ImageColumn"] = null; // No image available
                            }
                        }

                        // Remove the raw Photo column for cleaner display
                        dataTable.Columns.Remove("Photo");

                        // Bind the updated DataTable to the DataGridView
                        dataGridView2.DataSource = dataTable;

                        // Auto-size columns for better display
                        dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                        // Configure the image column for better presentation
                        if (dataGridView2.Columns.Contains("ImageColumn"))
                        {
                            DataGridViewImageColumn imageColumn = (DataGridViewImageColumn)dataGridView2.Columns["ImageColumn"];
                            imageColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
                        }

                        // Notify the user if no records are found
                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show("No records found matching the search criteria.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Generate a random number between 1 and 100
                Random rand = new Random();
                int randomOrderID = rand.Next(1, 101);

                // Check if the generated number already exists in the PlacedOrders table
                string query = "SELECT COUNT(*) FROM PlacedOrders WHERE OrderID = @OrderID";

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    // Add parameter for the random OrderID
                    sqlCommand.Parameters.AddWithValue("@OrderID", randomOrderID);

                    // Open the connection and execute the query
                    sqlConnection.Open();
                    int count = (int)sqlCommand.ExecuteScalar();

                    updateLables();
                    label9.Text = "- - - - -";
                    dataGridView1.DataSource = null;
                    dataGridView1.Rows.Clear();

                    // If the random number already exists, generate a new one
                    while (count > 0)
                    {
                        randomOrderID = rand.Next(1, 101); // Generate a new random number
                        sqlCommand.Parameters["@OrderID"].Value = randomOrderID;
                        count = (int)sqlCommand.ExecuteScalar(); // Re-check if the new number exists
                    }

                    // Assign the unique random OrderID to label9
                    label9.Text = randomOrderID.ToString();
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                // Ensure that a row is selected
                if (dataGridView2.SelectedRows.Count > 0)
                {
                    // Get the selected row
                    DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];

                    // Map the values from the selected row to the labels
                    string drugName = selectedRow.Cells["DrugName"].Value?.ToString();
                    string price = selectedRow.Cells["Price"].Value?.ToString();

                    // Set the labels' text based on the selected row's data
                    label7.Text = string.IsNullOrEmpty(drugName) ? "N/A" : drugName;
                    label8.Text = string.IsNullOrEmpty(price) ? "N/A" : price;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the values from the labels and textBox
                string drugName = label7.Text.Trim();
                decimal pricePerPiece = decimal.Parse(label8.Text.Trim());
                string orderID = label9.Text.Trim();
                int quantity = int.Parse(textBox2.Text.Trim());

                //decimal pricePerPiece;
                //int orderID;
                //int quantity;

                //// Validate the input
                //if (string.IsNullOrEmpty(drugName))
                //{
                //    MessageBox.Show("Drug Name cannot be empty.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}

                //if (!decimal.TryParse(label8.Text, out pricePerPiece))
                //{
                //    MessageBox.Show("Invalid Price per Piece.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}

                //if (!int.TryParse(label9.Text, out orderID))
                //{
                //    MessageBox.Show("Invalid Order ID.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}

                //if (!int.TryParse(textBox2.Text, out quantity) || quantity <= 0)
                //{
                //    MessageBox.Show("Quantity must be a positive integer.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}

                // SQL query to insert data into PlacedOrders
                string query = "INSERT INTO PlacedOrders (OrderID, DrugName, Quantity, PricePerPiece) VALUES (@OrderID, @DrugName, @Quantity, @PricePerPiece)";

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    // Add parameters to the SQL query
                    sqlCommand.Parameters.AddWithValue("@OrderID", orderID);
                    sqlCommand.Parameters.AddWithValue("@DrugName", drugName);
                    sqlCommand.Parameters.AddWithValue("@Quantity", quantity);
                    sqlCommand.Parameters.AddWithValue("@PricePerPiece", pricePerPiece);

                    // Open the connection and execute the insert query
                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();

                    // Reload data into dataGridView1 to display the added row
                    LoadPlacedOrdersData(orderID);
                    updateLables();
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadPlacedOrdersData(string orderID)
        {
            try
            {
                // SQL query to fetch all rows from the PlacedOrders table for a specific OrderID
                string query = "SELECT OrderID, DrugName, Quantity, PricePerPiece FROM PlacedOrders WHERE OrderID = @OrderID;";

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlDataAdapter dataAdapter = new SqlDataAdapter(query, sqlConnection))
                {
                    // Add the OrderID parameter to the SqlDataAdapter's command
                    dataAdapter.SelectCommand.Parameters.AddWithValue("@OrderID", orderID);

                    // Create a DataTable to hold the fetched data
                    DataTable dataTable = new DataTable();

                    // Fill the DataTable with data
                    dataAdapter.Fill(dataTable);

                    // Bind the DataTable to the dataGridView1
                    dataGridView1.DataSource = dataTable;

                    // Auto-size the columns for better readability
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while loading the data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Leave(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            label7.Text = "- - - - -";
            label8.Text = "- - - - -";
            label9.Text = "- - - - -";
            textBox2.Text = null;
            textBox4.Text = null;
        }
    }
}
