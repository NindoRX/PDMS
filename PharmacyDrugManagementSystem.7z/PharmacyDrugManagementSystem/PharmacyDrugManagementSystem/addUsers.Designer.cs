﻿namespace PharmacyDrugManagementSystem
{
    partial class addUsers
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            deleteBtn = new Button();
            label4 = new Label();
            label3 = new Label();
            updateBtn = new Button();
            button2 = new Button();
            label2 = new Label();
            dataGridView2 = new DataGridView();
            txtPassword = new TextBox();
            txtUserName = new TextBox();
            label1 = new Label();
            panel1 = new Panel();
            searchBtn = new Button();
            textBox1 = new TextBox();
            button1 = new Button();
            cmbRole = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.FromArgb(96, 113, 120);
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            deleteBtn.ForeColor = Color.White;
            deleteBtn.Location = new Point(615, 616);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(120, 34);
            deleteBtn.TabIndex = 14;
            deleteBtn.Text = "Delete";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deleteBtn_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(120, 670);
            label4.Name = "label4";
            label4.Size = new Size(48, 22);
            label4.TabIndex = 12;
            label4.Text = "Role";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(384, 122);
            label3.Name = "label3";
            label3.Size = new Size(77, 33);
            label3.TabIndex = 8;
            label3.Text = "Users";
            label3.Click += label3_Click;
            // 
            // updateBtn
            // 
            updateBtn.BackColor = Color.FromArgb(96, 113, 120);
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            updateBtn.ForeColor = Color.White;
            updateBtn.Location = new Point(615, 561);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(120, 34);
            updateBtn.TabIndex = 7;
            updateBtn.Text = "Update";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updateBtn_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(96, 113, 120);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(615, 505);
            button2.Name = "button2";
            button2.Size = new Size(120, 37);
            button2.TabIndex = 6;
            button2.Text = "Add";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(120, 611);
            label2.Name = "label2";
            label2.Size = new Size(88, 22);
            label2.TabIndex = 4;
            label2.Text = "Password";
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToAddRows = false;
            dataGridView2.AllowUserToDeleteRows = false;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(17, 173);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.ReadOnly = true;
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(834, 300);
            dataGridView2.TabIndex = 3;
            dataGridView2.SelectionChanged += dataGridView2_SelectionChanged_1;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(244, 611);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(217, 27);
            txtPassword.TabIndex = 1;
            // 
            // txtUserName
            // 
            txtUserName.Location = new Point(244, 552);
            txtUserName.Name = "txtUserName";
            txtUserName.Size = new Size(217, 27);
            txtUserName.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(120, 552);
            label1.Name = "label1";
            label1.Size = new Size(98, 22);
            label1.TabIndex = 0;
            label1.Text = "User Name";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(1, 39, 60);
            panel1.Controls.Add(searchBtn);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(cmbRole);
            panel1.Controls.Add(deleteBtn);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(updateBtn);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(dataGridView2);
            panel1.Controls.Add(txtPassword);
            panel1.Controls.Add(txtUserName);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(867, 743);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            panel1.Leave += panel1_Leave;
            // 
            // searchBtn
            // 
            searchBtn.BackColor = Color.FromArgb(96, 113, 120);
            searchBtn.FlatStyle = FlatStyle.Flat;
            searchBtn.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            searchBtn.ForeColor = Color.White;
            searchBtn.Location = new Point(523, 55);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(120, 37);
            searchBtn.TabIndex = 18;
            searchBtn.Text = "Search";
            searchBtn.UseVisualStyleBackColor = false;
            searchBtn.Click += searchBtn_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(142, 58);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(335, 34);
            textBox1.TabIndex = 17;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(96, 113, 120);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(615, 671);
            button1.Name = "button1";
            button1.Size = new Size(120, 37);
            button1.TabIndex = 16;
            button1.Text = "View Users";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // cmbRole
            // 
            cmbRole.FormattingEnabled = true;
            cmbRole.Items.AddRange(new object[] { "Pharmacist", "Cashier" });
            cmbRole.Location = new Point(244, 670);
            cmbRole.Name = "cmbRole";
            cmbRole.Size = new Size(217, 28);
            cmbRole.TabIndex = 15;
            // 
            // addUsers
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "addUsers";
            Size = new Size(867, 743);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Button deleteBtn;
        private Label label4;
        private Label label3;
        private Button updateBtn;
        private Button button2;
        private Label label2;
        private DataGridView dataGridView2;
        private TextBox txtPassword;
        private TextBox txtUserName;
        private Label label1;
        private Panel panel1;
        private ComboBox cmbRole;
        private Button button1;
        private Button searchBtn;
        private TextBox textBox1;
    }
}
