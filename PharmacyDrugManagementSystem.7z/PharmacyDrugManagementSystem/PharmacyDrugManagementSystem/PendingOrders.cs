﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace PharmacyDrugManagementSystem
{
    public partial class PendingOrders : UserControl
    {
        public PendingOrders()
        {
            InitializeComponent();
        }
        string conn = "Data Source=EXS\\SQLEXPRESS;Initial Catalog=PharmacyDrugInventoryMS;Integrated Security=True;Trust Server Certificate=True";
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string orderId = textBox4.Text.Trim();

            if (string.IsNullOrEmpty(orderId))
            {
                MessageBox.Show("Please enter a valid OrderID.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(conn))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT OrderID, DrugName, Quantity, Status FROM PlacedOrders WHERE OrderID = @OrderID";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@OrderID", orderId);

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count > 0)
                        {
                            dataGridView1.DataSource = dataTable;
                        }
                        else
                        {
                            MessageBox.Show("No records found for the given OrderID.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            dataGridView1.DataSource = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Get the selected row
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

            string orderID = selectedRow.Cells["orderID"].Value?.ToString();

            using (SqlConnection connection = new SqlConnection(conn))
            {
                try
                {
                    connection.Open();

                    // Begin a transaction for all operations
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Step 1: Get drugs with "Paid" status for the specified OrderID
                            string selectQuery = @"
                        SELECT DrugName, Quantity, PricePerPiece 
                        FROM PlacedOrders 
                        WHERE OrderID = @OrderID AND Status = 'Paid'";

                            DataTable placedOrders = new DataTable();
                            using (SqlCommand selectCommand = new SqlCommand(selectQuery, connection, transaction))
                            {
                                selectCommand.Parameters.AddWithValue("@OrderID", orderID);
                                SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
                                adapter.Fill(placedOrders);
                            }

                            if (placedOrders.Rows.Count == 0)
                            {
                                MessageBox.Show("No drugs with 'Paid' status found for the given OrderID.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                transaction.Rollback();
                                return;
                            }

                            // Step 2: Update Inventory and insert into SoldDrugs
                            foreach (DataRow row in placedOrders.Rows)
                            {
                                string drugName = row["DrugName"].ToString();
                                int quantity = Convert.ToInt32(row["Quantity"]);
                                decimal pricePerPiece = Convert.ToDecimal(row["PricePerPiece"]);

                                // Update Inventory
                                string updateInventoryQuery = @"
                            UPDATE Inventory 
                            SET Quantity = Quantity - @Quantity 
                            WHERE DrugName = @DrugName AND Quantity >= @Quantity";

                                using (SqlCommand updateCommand = new SqlCommand(updateInventoryQuery, connection, transaction))
                                {
                                    updateCommand.Parameters.AddWithValue("@DrugName", drugName);
                                    updateCommand.Parameters.AddWithValue("@Quantity", quantity);

                                    int rowsAffected = updateCommand.ExecuteNonQuery();
                                    if (rowsAffected == 0)
                                    {
                                        throw new Exception($"Not enough stock for drug: {drugName}.");
                                    }
                                }

                                // Insert into SoldDrugs
                                string insertSoldDrugsQuery = @"
                            INSERT INTO SoldDrugs (DrugName, Quantity, PricePerPiece) 
                            VALUES (@DrugName, @Quantity, @PricePerPiece)";

                                using (SqlCommand insertCommand = new SqlCommand(insertSoldDrugsQuery, connection, transaction))
                                {
                                    insertCommand.Parameters.AddWithValue("@DrugName", drugName);
                                    insertCommand.Parameters.AddWithValue("@Quantity", quantity);
                                    insertCommand.Parameters.AddWithValue("@PricePerPiece", pricePerPiece);
                                    insertCommand.ExecuteNonQuery();
                                }
                            }

                            // Step 3: Delete all data from PlacedOrders for the specified OrderID
                            string deletePlacedOrdersQuery = "DELETE FROM PlacedOrders WHERE OrderID = @OrderID";

                            using (SqlCommand deleteCommand = new SqlCommand(deletePlacedOrdersQuery, connection, transaction))
                            {
                                deleteCommand.Parameters.AddWithValue("@OrderID", orderID);
                                deleteCommand.ExecuteNonQuery();
                            }

                            // Commit the transaction
                            transaction.Commit();
                            MessageBox.Show("Operation completed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            button3_Click(null, null);
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void panel1_Leave(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            textBox4.Text = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT OrderID, Status FROM PlacedOrders GROUP BY OrderID, Status;";

                using (SqlConnection sqlConnection = new SqlConnection(conn))
                using (SqlDataAdapter dataAdapter = new SqlDataAdapter(query, sqlConnection))
                {
                    // Create a DataTable to hold the fetched data
                    DataTable dataTable = new DataTable();

                    // Fill the DataTable with data
                    dataAdapter.Fill(dataTable);

                    // Bind the DataTable to the dataGridView1
                    dataGridView1.DataSource = dataTable;

                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while loading the data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
